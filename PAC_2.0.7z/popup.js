document.addEventListener('DOMContentLoaded', function () { // Ожидание полной загрузки страницы

    var btnSettings = document.getElementById('btnSettings'); // Инициализация кнопки "Settings"
    btnSettings.addEventListener('click', function () { // Обработка нажатия
        chrome.tabs.create({ 'url': chrome.runtime.getURL('settings/settings.html') });
    }, false);

    var inputMinus = document.getElementById('inputMinus'); // Инициализация инпута "inputMinus"
    inputMinus.value = chrome.storage.local.get(['inputMinus']) || ''; // Получение сохранённого inputMinus
    inputMinus.addEventListener('input', function () { // Сохранение при изменении инпута
        chrome.storage.local.set({ inputMinus: inputMinus.value });
    });

    var btnChangeAll = document.getElementById('btnChangeAll'); // Инициализация кнопки "btnChangeAll"
    btnChangeAll.addEventListener('click', function () { // Обработка нажатия
        // Отправление сообщения в активную вкладку
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "findLinks" });
            console.log('findLinks sended');
        });
    });

    var btnTest = document.getElementById('test'); // Инициализация кнопки "test"
    btnTest.addEventListener('click', function () { // Обработка нажатия
        // Отправление сообщения в активную вкладку
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "performActionsOnLink" });
        });
    });

}, false);