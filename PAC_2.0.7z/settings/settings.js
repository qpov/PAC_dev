document.addEventListener('DOMContentLoaded', function () {
    // Load existing sellers and brands
    loadSellers();
    loadBrands();

    // Add seller
    document.getElementById('btnAddSeller').addEventListener('click', function () {
        var seller = document.getElementById('inputSeller').value.trim();
        if (seller) {
            addSeller(seller);
            document.getElementById('inputSeller').value = ''; // Clear input
        }
    });

    // Add brand
    document.getElementById('btnAddBrand').addEventListener('click', function () {
        var brand = document.getElementById('inputBrand').value.trim();
        if (brand) {
            addBrand(brand);
            document.getElementById('inputBrand').value = ''; // Clear input
        }
    });
});

function loadSellers() {
    chrome.storage.local.get(['sellers'], function(result) {
        var sellers = result.sellers || [];
        var sellersList = document.getElementById('sellersList');
        sellersList.innerHTML = ''; // Clear existing sellers list
        sellers.forEach(function (seller, index) {
            var el = document.createElement('div');
            el.textContent = seller;

            // Create delete button
            var deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            deleteBtn.onclick = function () {
                deleteSeller(index);
            };

            el.appendChild(deleteBtn);
            sellersList.appendChild(el);
        });
    });
}

function loadBrands() {
    chrome.storage.local.get(['brands'], function(result) {
        var brands = result.brands || [];
        var brandsList = document.getElementById('brandsList');
        brandsList.innerHTML = ''; // Clear existing brands list
        brands.forEach(function (brand, index) {
            var el = document.createElement('div');
            el.textContent = brand;

            // Create delete button
            var deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            deleteBtn.onclick = function () {
                deleteBrand(index);
            };

            el.appendChild(deleteBtn);
            brandsList.appendChild(el);
        });
    });
}

function addSeller(seller) {
    chrome.storage.local.get(['sellers'], function(result) {
        var sellers = result.sellers || [];
        sellers.push(seller);
        chrome.storage.local.set({ sellers: sellers }, function() {
            loadSellers(); // Refresh the sellers display
        });
    });
}

function addBrand(brand) {
    chrome.storage.local.get(['brands'], function(result) {
        var brands = result.brands || [];
        brands.push(brand);
        chrome.storage.local.set({ brands: brands }, function() {
            loadBrands(); // Refresh the brands display
        });
    });
}

function deleteSeller(index) {
    chrome.storage.local.get(['sellers'], function(result) {
        var sellers = result.sellers || [];
        sellers.splice(index, 1); // Remove item at index
        chrome.storage.local.set({ sellers: sellers }, function() {
            loadSellers(); // Refresh the sellers display
        });
    });
}

function deleteBrand(index) {
    chrome.storage.local.get(['brands'], function(result) {
        var brands = result.brands || [];
        brands.splice(index, 1); // Remove item at index
        chrome.storage.local.set({ brands: brands }, function() {
            loadBrands(); // Refresh the brands display
        });
    });
}