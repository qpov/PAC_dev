chrome.runtime.onMessage.addListener(function (request) { // Обработка сообщения
    if (request.action === "findLinks") {
        console.log('findLinks received');
        // Поиск всех элементов <a class="picture">
        var links = Array.from(document.querySelectorAll('a.picture')).map(link => link.href);

        // Отправка массив ссылок в background.js
        chrome.runtime.sendMessage({ action: "sendLinks", links: links });
        console.log('sendLinks sended');
    }
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) { // Обработка сообщения
    if (request.action === "performActionsOnLink") {
        const observer = new MutationObserver((mutations) => { // Динамический поиск элементов
            const offersHeader = document.querySelector('.d-flex.align-items-center');
            const offersTableBody = document.getElementById('offers_table_body');

            if (offersHeader && offersHeader.textContent.includes('Торговые предложения')) { // Запуск скрипта если текст появился
                if (offersTableBody && offersTableBody.innerHTML.includes('К сожалению, в выбранный Вами город доставки')) {
                    console.log("Найден текст о отсутствии предложений");
                    sendResponse({ status: "completed" }); // Отправка ответа для закрытия вкладки
                } else {
                    console.log("Текст о отсутствии предложений не найден");
                    // Поиск div class="propertyList"
                    const propertyList = document.querySelector('.propertyList');
                    if (propertyList) {
                        // Поиск бренда
                        // Поиск всех div class="propertyValue" внутри propertyList
                        const propertyValues = propertyList.querySelectorAll('.propertyValue');
                        // Проверка, есть ли хотя бы два элемента propertyValue
                        if (propertyValues.length >= 2) {
                            // Сохранение текста из второго div class="propertyValue" в localStorage
                            const brandText = propertyValues[1].textContent;
                            localStorage.setItem('brand', brandText);
                            console.log('Текст сохранён в localStorage под ключом "brand":', brandText);
                        }

                        // Проверяем, есть ли кнопка с id "collapse_btn_arrow"
                        const button = document.getElementById('collapse_btn_arrow');

                        if (button) {
                            // Если кнопка существует, нажимаем на нее
                            button.click();
                            const dataArray = []; // Инициализируем пустой массив для хранения извлеченных данных
                            extractDataFromCardBodies(dataArray);

                            const dataArray2 = [];
                            extractPriceAndCompany(dataArray2);

                            findLowestPrice(dataArray, dataArray2);

                            checkForMatches()
                                .then(result => {
                                    console.log(`Результат: ${result}`);
                                    if (result === true) {
                                        sendResponse({ status: "completed" }); // Отправка ответа для закрытия вкладки
                                    }
                                })
                                .catch(error => {
                                    console.error(`Ошибка: ${error}`);
                                });
                        } else {
                            const dataArray = []; // Инициализируем пустой массив для хранения извлеченных данных
                            extractDataFromCardBodies(dataArray);

                            const dataArray2 = [];
                            extractPriceAndCompany(dataArray2);

                            findLowestPrice(dataArray, dataArray2);

                            checkForMatches()
                                .then(result => {
                                    console.log(`Результат: ${result}`);
                                    if (result === true) {
                                        sendResponse({ status: "completed" }); // Отправка ответа для закрытия вкладки
                                    }
                                })
                                .catch(error => {
                                    console.error(`Ошибка: ${error}`);
                                });

                            priceChange();
                        }
                    }
                    //sendResponse({ status: "completed" }); // Отправка ответа для закрытия вкладки
                }
                observer.disconnect(); // Отключение динамического наблюдения/поиска
            }
        });

        const observerConfig = {
            childList: true,
            subtree: true
        };

        observer.observe(document.body, observerConfig);
    }
    return true; // Важно вернуть true для асинхронного ответа
});

function extractDataFromCardBodies(dataArray) {
    // Находим все элементы с классом "card-body"
    const cardBodyElements = document.querySelectorAll('.card-body');

    // Игнорируем первый и последний элемент
    for (let i = 1; i < cardBodyElements.length - 1; i++) {
        const cardBody = cardBodyElements[i];

        // Получаем данные из элемента card-body (аналогично вашему существующему коду)
        const companyNameElement = cardBody.querySelector('p.text-left');
        const priceElement = cardBody.querySelector('.table-bordered tr:nth-child(2) td:nth-child(2)');

        if (companyNameElement && priceElement) {
            const companyName = companyNameElement.textContent.trim();
            const price = parseFloat(priceElement.textContent.trim().replace(',', '.')); // Преобразуем цену в число

            // Добавляем данные в массив
            dataArray.push({ companyName: companyName, price: price });
        } else {
            console.error('Не удалось найти элементы с данными');
        }
    }
    // Выводим массив в лог
    console.log('Оптовые предложения (dataArray):', dataArray);
    return dataArray;
}

function extractPriceAndCompany(dataArray2) {
    // Находим элемент <table> с классом "table-bordered"
    const table = document.querySelector('table.table-bordered');

    if (table) {
        // Находим все строки в таблице
        const rows = table.querySelectorAll('tr');

        // Проверяем, что есть как минимум 2 строки
        if (rows.length >= 2) {
            // Получаем вторую строку
            const secondRow = rows[1];

            // Находим второй <td> в строке
            const tds = secondRow.querySelectorAll('td');
            if (tds.length >= 2) {
                // Извлекаем название компании (предполагая, что это первый <td>)
                const companyName = tds[0].querySelector('a.col-9.shop_name_col').textContent.trim();
                const price = tds[1].textContent.trim();

                // Сохраняем данные в массив
                //dataArray2.push({ companyName, price });
                dataArray2.push({ companyName: companyName, price: price });
                // Выводим данные в лог
                //console.log(`Название компании: ${companyName}, Цена: ${price}`);
                console.log('Первый в списке (dataArray2):', dataArray2);
                return dataArray2;
            } else {
                console.error('Недостаточно элементов <td> во второй строке.');
            }
        } else {
            console.error('Недостаточно строк в таблице.');
        }
    } else {
        console.error('Таблица с классом "table-bordered" не найдена.');
    }
}

function findLowestPrice(dataArray, dataArray2) {
    // Проверяем, что dataArray не пустой
    if (dataArray.length === 0) {
        console.log('dataArray пустой.');

        // Если dataArray2 не пустой, то находим компанию с самой низкой ценой
        if (dataArray2.length > 0) {
            const lowestPriceCompany = dataArray2[0].companyName;
            const lowestPrice = dataArray2[0].price;

            console.log(`Компания с самой низкой ценой: ${lowestPriceCompany} (Цена: ${lowestPrice})`);

            // Сохраняем данные в localStorage
            localStorage.setItem('lowestPriceCompany', lowestPriceCompany);
            localStorage.setItem('lowestPrice', lowestPrice);
        } else {
            console.log('dataArray2 пустой.');
        }

        return;
    }

    // Объединяем два массива
    const combinedData = [...dataArray, ...dataArray2];

    // Отладочный вывод для проверки содержимого combinedData
    console.log('combinedData:', combinedData);

    // Инициализируем переменные для хранения самой низкой цены и соответствующей компании
    let lowestPrice = Infinity;
    let lowestPriceCompany = null;

    // Итерируемся по каждой компании в объединенных данных
    for (const companyData of combinedData) {
        const { companyName, price } = companyData;

        // Проверяем, если текущая цена ниже самой низкой цены
        if (price < lowestPrice) {
            lowestPrice = price;
            lowestPriceCompany = companyName;
        }
    }

    // Выводим результат в лог
    console.log(`Компания с самой низкой ценой: ${lowestPriceCompany} (Цена: ${lowestPrice})`);

    // Сохраняем данные в localStorage
    localStorage.setItem('lowestPriceCompany', lowestPriceCompany);
    localStorage.setItem('lowestPrice', lowestPrice);
}

function checkForMatches() {
    return new Promise((resolve, reject) => {
        // Получаем значение из localStorage
        const lowestPriceCompany = localStorage.getItem('lowestPriceCompany');

        chrome.storage.local.get(['sellers'], function (result) {
            const sellers = result.sellers || [];

            console.log(`Поиск ${lowestPriceCompany} среди сохранённых продавцов`);

            // Проверяем наличие совпадений
            if (sellers && sellers.includes(lowestPriceCompany)) {
                resolve(true);
            } else {
                resolve(false);
            }
        });
    });
}

function priceChange() {

}