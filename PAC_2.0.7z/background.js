chrome.runtime.onMessage.addListener(function (request) { // Обработка сообщения
    if (request.action === "sendLinks") {
        console.log('sendLinks received', request.links);

        // Начинаем открывать ссылки по одной
        openLinksSequentially([...request.links]);
    }
});

// Функция для последовательного открытия ссылок
function openLinksSequentially(links) {
    if (links.length === 0) {
        return; // Если ссылок нет, выход из функции
    }

    const link = links.shift(); // Получение первой ссылки и удаление ее из массива

    chrome.tabs.create({ url: link, active: true }, (tab) => { // Создание новой вкладки
        chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) { // Ожидание полной загрузки вкладки
            if (tabId === tab.id && changeInfo.status === 'complete') {

                chrome.tabs.sendMessage(tab.id, { action: "performActionsOnLink", link: link }, function (response) { // Отправка сообщения для обработки вкладки
                    console.log('performActionsOnLink sended');
                    if (chrome.runtime.lastError) {
                        // Обработка ошибки, если content script не ответил
                        console.log("Error sending message to content script:", chrome.runtime.lastError.message);
                    } else if (response.status === "completed") {
                        chrome.tabs.remove(tab.id); // Закрываем вкладку после обработки
                        openLinksSequentially(links);
                    }
                });

                // Удаляем слушатель, так как он больше не нужен
                chrome.tabs.onUpdated.removeListener(listener);
            }
        });
    });
}